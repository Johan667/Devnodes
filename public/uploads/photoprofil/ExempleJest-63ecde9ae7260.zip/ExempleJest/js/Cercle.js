class Cercle {
    constructor(rayon) {
      this.rayon = rayon;
    }

    setRayon(rayon) {
        this.rayon = rayon; 
    }

    getRayon() {
        return this.rayon; 
    }
}

module.exports = Cercle;
