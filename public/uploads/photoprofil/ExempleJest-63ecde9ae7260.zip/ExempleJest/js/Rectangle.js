class Rectangle {
    constructor(hauteur, largeur) {
      this.hauteur = hauteur;
      this.largeur = largeur;
    }

    setHauteur(hauteur) {
        this.hauteur = hauteur;
    }
    
    setLargeur(largeur) {
        this.largeur = largeur;
    }

    getHauteur() {
        return this.hauteur;
    }
    
    getLargeur() {
        return this.largeur;
    }
}

module.exports = Rectangle;