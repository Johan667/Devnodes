class LesGensFontNimpException extends Error {
    constructor(message) {
      super(message);
      this.name = this.constructor.name;
    }
  }

function ajouter(a, b) {
    return a + b;
}

function fonctionQuiThrow() {
    throw new LesGensFontNimpException('Vous faites n\'imp!');
}

function operateurPositif(callback, nombre) {
    if (nombre >= 0) {
        callback(nombre);
    }
}

function operateurPositifTab(callback, elements) {
    for (const i of elements) {
        if (i >= 0) {
            callback(i);
        }
    }
}

async function donneTemps(lieu) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            fetch('http://api.weatherstack.com/current?access_key=c3554e7809996246545fb5c2ad7162cb&query=' + lieu)
            .then((reponse) => resolve(reponse.json())) 
        }, 3000)
    });
}

async function donneTempsRejet(lieu) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            fetch('http://api.weatherstack.com/current?access_key=c3554e7809996246545fb5c2ad7162cb&query=' + lieu)
            .then((reponse) => reponse.json())
            .then((data) => {
                if ('request' in data) {
                    resolve(data);
                } else {
                   reject('Le lieu ' + lieu + ' est incconu'); 
                }
            }) 
        }, 3000)
    });
}

module.exports = { 
    ajouter, 
    fonctionQuiThrow, 
    LesGensFontNimpException, 
    operateurPositif,
    operateurPositifTab,
    donneTemps,
    donneTempsRejet
};